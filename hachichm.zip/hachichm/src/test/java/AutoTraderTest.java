import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import static java.lang.Thread.sleep;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class AutoTraderTest {


    WebDriver driver;
    private static ExtentReportManager reportManager;
    private Wait<WebDriver> wait;
    List<String> row;

    @BeforeClass
    public static void init() {
        String property = System.getProperty("user.dir");
        ReportDetails reportDetails = new ReportDetails(property + "\\TestReport",
                "Basic Extent Report", "Basic Report");
        reportManager = new ExtentReportManager(ExtentReportManager.ReportType.HTML, reportDetails);
    }

    @Before
    public void myBeforeMethod() {
        driver = new ChromeDriver();

        wait = new FluentWait<WebDriver>(driver)
                .withTimeout(30, TimeUnit.SECONDS)
                .pollingEvery(5, TimeUnit.SECONDS)
                .ignoring(NoSuchElementException.class);
    }

    @Test
    public void passingLogLevelTest() {
        ExtentTest passingLogLevelTest = reportManager.setUpTest();
        passingLogLevelTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                " person to understand what the test is doing");
        passingLogLevelTest.log(Status.DEBUG,
                "Debug level message to display any information a TECHNICAL person might need to know");
        passingLogLevelTest.pass("Training.Example passing test");
    }


    @Test
    public void carRegValidation() throws IOException, InterruptedException {
        driver.navigate().to("http://www.autotrader.co.uk/");
        ExtentTest extentTest = reportManager.setUpTest();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

        String imagePath = ScreenShot.take(driver, "image");

        SpreadSheetReader sheetReader = new SpreadSheetReader(System.getProperty("user.dir") + "/src/main/resources/AutoTrader.xlsx");


        row = sheetReader.readRow(1, "sheet1");
        // System.out.println(row.get(1));


        driver.findElement(By.xpath("//*[@id=\"js-editorial-content\"]/section[1]/div/form/input[1]")).sendKeys(row.get(1));
        sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"js-editorial-content\"]/section[1]/div/form/input[2]")).sendKeys(row.get(2));
        sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"js-editorial-content\"]/section[1]/div/form/button")).click();
        sleep(1000);

        try {

            assertTrue(driver.findElement(By.id("vehicle-description")).getText().equalsIgnoreCase("Volkswagen Polo"));
            extentTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                    " person to understand what the test is doing");
            extentTest.pass("Passed");
            System.out.println("Passed");
        } catch (AssertionError e) {
            String details = "Training.Example Failing test: " + e.getMessage();
            extentTest.fail(details);
            Assert.fail(details);
            extentTest.log(Status.WARNING, "Used to report an issue that may cause problems within a system");
            extentTest.log(Status.ERROR, "Used to report an issue that will cause problems within a system");
            extentTest.addScreenCaptureFromPath(imagePath);
            extentTest.log(Status.FATAL, "Used to report an issue that will fail/break the system");

        }
    }


    @Test
    public void searchNewCar() throws IOException, InterruptedException {
        driver.navigate().to("http://www.autotrader.co.uk/");
        ExtentTest extentTest = reportManager.setUpTest();

        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        String imagePath = ScreenShot.take(driver, "image");

        SpreadSheetReader sheetReader = new SpreadSheetReader(System.getProperty("user.dir") + "/src/main/resources/AutoTrader.xlsx");


        row = sheetReader.readRow(2, "sheet1");
        //System.out.println(row.get(1));

        driver.findElement(By.xpath("//*[@id=\"js-header-nav\"]/ul/li[1]/a")).click();
        sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"top-nav__buying\"]/li[2]/a")).click();
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/select")).click();
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[1]/select")).sendKeys(row.get(1));
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/select")).click();
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/select")).sendKeys(row.get(2));
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
        sleep(1000);

        try {
            assertTrue(driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/h1/span[2]")).getText().equalsIgnoreCase("A5"));
            extentTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                    " person to understand what the test is doing");
            extentTest.pass("Passed");
            System.out.println("Passed");
        } catch (AssertionError e) {
            String details = "Training.Example Failing test: " + e.getMessage();
            extentTest.fail(details);
            Assert.fail(details);
            extentTest.log(Status.WARNING, "Used to report an issue that may cause problems within a system");
            extentTest.log(Status.ERROR, "Used to report an issue that will cause problems within a system");
            extentTest.addScreenCaptureFromPath(imagePath);
            extentTest.log(Status.FATAL, "Used to report an issue that will fail/break the system");

        }
    }


    @Test
    public void aboutUs() throws IOException, InterruptedException {
        driver.navigate().to("http://www.autotrader.co.uk/");
        ExtentTest extentTest = reportManager.setUpTest();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        String imagePath = ScreenShot.take(driver, "image");


        driver.findElement(By.xpath("//*[@id=\"home\"]/div[6]/footer/div/nav[1]/section[1]/ul/li[1]/a")).click();

        try {

            assertTrue(driver.getTitle().equals("About Us - About Auto Trader UK"));
            extentTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                    " person to understand what the test is doing");
            extentTest.pass("Passed");
            System.out.println("Passed");


        } catch (AssertionError e) {
            String details = "Training.Example Failing test: " + e.getMessage();
            extentTest.fail(details);
            Assert.fail(details);
            extentTest.log(Status.WARNING, "Used to report an issue that may cause problems within a system");
            extentTest.log(Status.ERROR, "Used to report an issue that will cause problems within a system");
            extentTest.addScreenCaptureFromPath(imagePath);
            extentTest.log(Status.FATAL, "Used to report an issue that will fail/break the system");
            System.out.println("error");

        }
    }

    @Test
    public void checkHomepage() throws IOException, InterruptedException {
        driver.navigate().to("http://www.autotrader.co.uk/");
        ExtentTest extentTest = reportManager.setUpTest();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        String imagePath = ScreenShot.take(driver, "image");


        try {

            assertTrue(driver.getTitle().equalsIgnoreCase("Auto Trader UK | Find New & Used Cars for Sale"));
            extentTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                    " person to understand what the test is doing");
            extentTest.pass("Passed");
            System.out.println("Passed");


        } catch (AssertionError e) {
            String details = "Training.Example Failing test: " + e.getMessage();
            extentTest.fail(details);
            Assert.fail(details);
            extentTest.log(Status.WARNING, "Used to report an issue that may cause problems within a system");
            extentTest.log(Status.ERROR, "Used to report an issue that will cause problems within a system");
            extentTest.addScreenCaptureFromPath(imagePath);
            extentTest.log(Status.FATAL, "Used to report an issue that will fail/break the system");
            System.out.println("error");

        }
    }


    @Test
    public void viewReview() throws IOException, InterruptedException {
//TAKES LONG TIME TO LAOD WEBPAGE FOR SOME REASON BUT TEST WORK EVENTUALLY!!
        driver.navigate().to("https://www.autotrader.co.uk/content");
        ExtentTest extentTest = reportManager.setUpTest();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        String imagePath = ScreenShot.take(driver, "image");

        SpreadSheetReader sheetReader = new SpreadSheetReader(System.getProperty("user.dir") + "/src/main/resources/AutoTrader.xlsx");
        row = sheetReader.readRow(5, "sheet1");

        driver.findElement(By.xpath("/html/body/div[1]/div/form/div[1]")).click();
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/div/form/div[1]/select")).sendKeys(row.get(1));
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/div/form/div[2]")).click();
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/div/form/div[2]/select")).sendKeys(row.get(2));
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/div/form/button")).click();
        driver.findElement(By.xpath("/html/body/main/section[2]/article[1]/span[2]/h2/a")).click();
        sleep(1000);

        try {
            assertTrue(driver.getTitle().equalsIgnoreCase("Audi A4 Allroad Estate (2016 - ) review | Auto Trader UK"));
            extentTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                    " person to understand what the test is doing");
            extentTest.pass("Passed");
            System.out.println("Passed");

        } catch (AssertionError e) {
            String details = "Training.Example Failing test: " + e.getMessage();
            extentTest.fail(details);
            Assert.fail(details);
            extentTest.log(Status.WARNING, "Used to report an issue that may cause problems within a system");
            extentTest.log(Status.ERROR, "Used to report an issue that will cause problems within a system");
            extentTest.addScreenCaptureFromPath(imagePath);
            extentTest.log(Status.FATAL, "Used to report an issue that will fail/break the system");
            System.out.println("error");

        }
    }


    @Test
    public void carFinance() throws IOException, InterruptedException {
        driver.navigate().to("http://www.autotrader.co.uk/");

        //*[@id="js-header-nav"]/ul/li[4]/a/span
        ExtentTest extentTest = reportManager.setUpTest();
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
        String imagePath = ScreenShot.take(driver, "image");
        Actions builder = new Actions(driver);
        SpreadSheetReader sheetReader = new SpreadSheetReader(System.getProperty("user.dir") + "/src/main/resources/AutoTrader.xlsx");
        row = sheetReader.readRow(6, "sheet1");

        driver.findElement(By.xpath("//*[@id=\"js-header-nav\"]/ul/li[4]/a/span")).click();
        sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"top-nav__services\"]/li[2]/a")).click();
        sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/section[1]/div/form/div[1]/section[1]/label[3]")).click();
        sleep(1000);

        builder.dragAndDropBy(driver.findElement(By.xpath("/html/body/div[1]/section[1]/div/form/div[1]/section[2]/div[1]/div/div/div[2]/div/div/div[1]")), 300, 200).perform();
        builder.dragAndDropBy(driver.findElement(By.xpath("/html/body/div[1]/section[1]/div/form/div[1]/section[2]/div[2]/div/div/div[2]/div/div/div[1]")), -300, 200).perform();


        try {

            assertNotEquals("£8,500", driver.findElement(By.xpath("/html/body/div[1]/section[1]/div/form/div[2]/p[1]/span[1]")).getText());
            extentTest.log(Status.INFO, "Info level message to show information that allows a NON-TECHNICAL" +
                    " person to understand what the test is doing");
            extentTest.pass("Passed");
            System.out.println("Passed");


        } catch (AssertionError e) {
            String details = "Training.Example Failing test: " + e.getMessage();
            extentTest.fail(details);
            Assert.fail(details);
            extentTest.log(Status.WARNING, "Used to report an issue that may cause problems within a system");
            extentTest.log(Status.ERROR, "Used to report an issue that will cause problems within a system");
            extentTest.addScreenCaptureFromPath(imagePath);
            extentTest.log(Status.FATAL, "Used to report an issue that will fail/break the system");
            System.out.println("error");

        }


    }

    @Test
    public void findDealer() throws IOException, InterruptedException {


    }

    @Test
    public void viewCareers() throws IOException, InterruptedException {


    }

    @Test
    public void refineCarSelection() throws IOException, InterruptedException {


    }

    @Test
    public void learnDriving() throws IOException, InterruptedException {


    }


    @After
    public void myAfterMethod() {
        reportManager.clearTests();
        driver.quit();

    }


}


